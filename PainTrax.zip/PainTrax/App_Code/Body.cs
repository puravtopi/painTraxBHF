﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Body
/// </summary>
public class Body
{
	public Body()
	{
		//
		// TODO: Add constructor logic here
		//
      
	}
    public string Part { get; set; }
    public string Position { get; set; }
}
