﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BodyParts
/// </summary>
public class BodyParts
{
	public BodyParts()
	{
		//
		// TODO: Add constructor logic here
		//
       
	}
    public string Parts { get; set; }
    public bool Checked { get; set; }
}